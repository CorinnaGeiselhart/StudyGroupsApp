package com.example.studygroups;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class StartView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_account);
    }
}
